#ifndef _TERMFIND_H_
#define _TERMFIND_H_

int termSetupTypes( char *terms[], int numTerms );
int termFind(char *str);

#endif